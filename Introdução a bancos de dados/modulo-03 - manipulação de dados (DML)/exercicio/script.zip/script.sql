Não colocarei os id porque estou levando em conta como os criei com "serial".
INSERT INTO customer (cpf, email, name) VALUES ('123.321.654.55', 'joao@uol.com', 'joao');

INSERT INTO product (name, value) VALUES ('biscoito', 2.99)

INSERT INTO stock (cod_product, amount) VALUES (1, 20)